import './globals.css';
export const metadata = { title: 'Prayas Special Batch', description: 'Your learning space for Physics, Chemistry and Mathematics.' };
export default function RootLayout({ children }) { return <html lang="en"><body>{children}</body></html>; }
